set={1,2,3,4,5,6}
print(f"the set before deletion is {set}")
set.discard(4)
print(f"The set after discarding 4 is {set}")