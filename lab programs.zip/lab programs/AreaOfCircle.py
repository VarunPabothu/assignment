from math import pi
r=int(input("enter the radius of the circle:"))
a=pi*r**2
print(f"the area of the circle is {a}")