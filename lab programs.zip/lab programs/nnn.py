n=input("Enter an integer number:")
nn=n*2
nnn=n*3
sum=int(n)+int(nn)+int(nnn)
print(f"the sum of {n}+{nn}+{nnn} is :{sum}")