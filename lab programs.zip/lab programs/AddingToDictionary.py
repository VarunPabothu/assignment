dict={0:10,
      1:20}

print(f"The dictionary before updation is {dict}")
dict.update({2:30})
print(f"The dictionary after updation is {dict}")
