m=int(input("Enter the number to print multiplication table:"))
for count in range (1,11):
    print(m,"x",count,"=",m*count)