celcius=float(input("Enter the temperature in celcius:"))
fahrenheit=(celcius*9/5)+32
print(f"The temperature in fahrenheit is {fahrenheit}")


fahrenheit=float(input("Enter the temperature in fahrneheit:"))
celcius=(fahrenheit-32)*5/9
print(f"The temperature in cecius is {celcius}")
